// Get references to the SVG elements
const bar = document.getElementById("bar");
const percentageText = document.getElementById("percentage");
const startButton = document.getElementById("start-animation");

// Function to animate the bar width
function animateBar() {
  const svgWidth = document.getElementById("bar-chart").getAttribute("width");
  const percentageValue = parseInt(percentageText.textContent); // Extract number from "75%"
  const targetWidth = (percentageValue / 100) * svgWidth; // Calculate width based on percentage

  // Animate the bar width
  bar.setAttribute("width", targetWidth);
}

// Function to handle button click
startButton.addEventListener("click", () => {
  animateBar();
});
